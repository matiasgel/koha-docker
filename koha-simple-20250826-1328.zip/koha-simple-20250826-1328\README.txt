﻿Backup Simple de Koha
=====================
Fecha: 08/26/2025 13:28:41
Host: DESKTOP-SR23V3U

Contenido:
- koha-database.sql: Base de datos de Koha
- docker-compose.yaml: ConfiguraciÃ³n de Docker
- rabbitmq_plugins: ConfiguraciÃ³n de RabbitMQ

RestauraciÃ³n en nueva mÃ¡quina:
1. Instalar Docker y Docker Compose
2. Copiar archivos a directorio de trabajo
3. Ejecutar comandos:

docker-compose up -d db
Start-Sleep -Seconds 30
Get-Content koha-database.sql | docker exec -i examples-db-1 mariadb -u root -pexample koha_teolib
docker-compose up -d

Credenciales:
- Usuario web installer: koha_teolib
- ContraseÃ±a: example
